scipy.odr.Model
===============

.. currentmodule:: scipy.odr

.. autoclass:: ODR
