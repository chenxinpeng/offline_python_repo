.. include:: ../../neps/math_config_clean.rst
