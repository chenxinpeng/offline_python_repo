#ifndef _NPY_ARRAY_GETSET_H_
#define _NPY_ARRAY_GETSET_H_

#ifdef NPY_ENABLE_SEPARATE_COMPILATION
extern NPY_NO_EXPORT PyGetSetDef array_getsetlist[];
#endif

#endif
