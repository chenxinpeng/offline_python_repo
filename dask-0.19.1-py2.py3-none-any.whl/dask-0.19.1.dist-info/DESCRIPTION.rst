Dask
====

|Build Status| |Coverage| |Doc Status| |Gitter| |Version Status|

Dask is a flexible parallel computing library for analytics.  See
documentation_ for more information.


LICENSE
-------

New BSD. See `License File <https://github.com/dask/dask/blob/master/LICENSE.txt>`__.

.. _documentation: http://dask.pydata.org/en/latest/
.. |Build Status| image:: https://travis-ci.org/dask/dask.svg?branch=master
   :target: https://travis-ci.org/dask/dask
.. |Coverage| image:: https://coveralls.io/repos/dask/dask/badge.svg
   :target: https://coveralls.io/r/dask/dask
   :alt: Coverage status
.. |Doc Status| image:: http://readthedocs.org/projects/dask/badge/?version=latest
   :target: http://dask.pydata.org/en/latest/
   :alt: Documentation Status
.. |Gitter| image:: https://badges.gitter.im/Join%20Chat.svg
   :alt: Join the chat at https://gitter.im/dask/dask
   :target: https://gitter.im/dask/dask?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
.. |Version Status| image:: https://img.shields.io/pypi/v/dask.svg
   :target: https://pypi.python.org/pypi/dask/


